package com.avk.hql;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class DeleteHQL {
	public static void main(String[] args) {
		SessionFactory factory = 
			new Configuration().configure().buildSessionFactory();
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction(); 
		
		Query query = session.createQuery("delete from Student s  where s.regdno=:rno");
		
		
		query.setParameter("rno", 3);
		
		int count = query.executeUpdate();
		
		tx.commit();
		if(count>0){
			System.out.println("Deletion successful");
		} else {
			System.out.println("Deletion failed, try again!!!!!!!!");
		}
		session.close();
		factory.close();
		
		
	}
}
