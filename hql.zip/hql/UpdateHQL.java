package com.avk.hql;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class UpdateHQL {
	
	public static void main(String[] args) {
		SessionFactory factory = 
			new Configuration().configure().buildSessionFactory();
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction(); 
		
		Query query = session.createQuery("update Student s set s.cgpa=:gpa where s.regdno=:rno");
		
		
		query.setParameter("rno", 3);
		query.setParameter("gpa", 9);
		
		int count = query.executeUpdate();
		
		tx.commit();
		if(count>0){
			System.out.println("Updation successful");
		} else {
			System.out.println("Updation failed, try again!!!!!!!!");
		}
		session.close();
		factory.close();
		
		
	}

}
