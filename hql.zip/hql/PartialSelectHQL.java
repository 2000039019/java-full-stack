package com.avk.hql;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.avk.annotation.Student;

public class PartialSelectHQL {
	public static void main(String[] args) {
		SessionFactory factory = 
			new Configuration().configure().buildSessionFactory();
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction(); 
		
	//	Student s = (Student)session.load(Student.class, 2);
		Query query = session.createQuery("select s.regdno, s.sname from Student s where s.cgpa>? ");
		query.setParameter(0, 7);
		
		List<Object[]> list = query.list();
		
		Iterator<Object[]> iter = list.iterator();
		
		while(iter.hasNext()){
			Object[] obj = iter.next();
	System.out.println(obj[0]+":"+obj[1]);
			
		}
		tx.commit();
		System.out.println("Selection is successful");
		session.close();
		factory.close();
		
		
	}

}
