package com.avk.hql;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.avk.annotation.Student;

public class SelectConditionHQL {
	
	public static void main(String[] args) {
		SessionFactory factory = 
			new Configuration().configure().buildSessionFactory();
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction(); 
		
	//	Student s = (Student)session.load(Student.class, 2);
		Query query = session.createQuery("from Student s where s.cgpa>? order by s.sname");
		query.setParameter(0, 7);
		
		List<Student> list = query.list();
		
		Iterator<Student> iter = list.iterator();
		
		while(iter.hasNext()){
			Student stu = iter.next();
	System.out.println(stu.getRegdno()+":"+stu.getSname()+":"+stu.getCgpa());
			
		}
		tx.commit();
		System.out.println("Selection is successful");
		session.close();
		factory.close();
		
		
	}

}
