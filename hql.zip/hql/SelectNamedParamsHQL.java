package com.avk.hql;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.avk.annotation.Student;

public class SelectNamedParamsHQL {
	
	public static void main(String[] args) {
		SessionFactory factory = 
			new Configuration().configure().buildSessionFactory();
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction(); 
		
	//	Student s = (Student)session.load(Student.class, 2);
		Query query = session.createQuery("from Student s where s.cgpa>:gpa order by s.sname");
		query.setParameter("gpa", 7);
		
		List<Student> list = query.list();
		
		Iterator<Student> iter = list.iterator();
		
		while(iter.hasNext()){
			Student stu = iter.next();
	System.out.println(stu.getRegdno()+":"+stu.getSname()+":"+stu.getCgpa());
			
		}
		tx.commit();
		System.out.println("Selection is successful");
		session.close();
		factory.close();
		
		
	}

}
