package com.avk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sec13SpringbootWebmvcCrudJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Sec13SpringbootWebmvcCrudJpaApplication.class, args);
	}

}
